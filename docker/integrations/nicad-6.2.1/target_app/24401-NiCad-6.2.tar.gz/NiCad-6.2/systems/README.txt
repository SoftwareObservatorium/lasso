We suggest copying any systems to be processed 
into this directory when running NiCad in place.

Example:
    cp -R /my/path/my-java-system systems/my-java-system
    ./nicad6 functions java systems/my-java-system 

